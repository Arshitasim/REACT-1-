import React from 'react';

function BookList({ books, onRemoveBook }) {
  return (
    <div>
      <h2>Book List</h2>
      {books.length === 0 ? (
        <p>No books available</p>
      ) : (
        <ul style={{ listStyleType: 'none', padding: 0 }}>
          {books.map(book => (
            <li key={book.id} style={{ margin: '10px 0', borderBottom: '1px solid #ccc', paddingBottom: '5px' }}>
              <strong>{book.title}</strong> by {book.author}
              <button 
                onClick={() => onRemoveBook(book.id)} 
                style={{ marginLeft: '10px', padding: '5px 10px', backgroundColor: 'red', color: 'white', border: 'none', borderRadius: '5px' }}
              >
                Remove
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default BookList;