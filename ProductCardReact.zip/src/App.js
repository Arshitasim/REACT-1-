import React from 'react';
import ProductCard from './components/ProductCard';

function App() {
  return (
    <div style={{ display: 'flex', gap: '20px', padding: '20px' }}>
      <ProductCard name="Laptop" price={59999} inStock={true} />
      <ProductCard name="Headphones" price={1999} inStock={false} />
      <ProductCard name="Smartphone" price={29999} inStock={true} />
    </div>
  );
}

export default App;