import React, { useEffect } from 'react';
import { Person, Student, Teacher } from './classes';

function App() {
  useEffect(() => {
    const student = new Student("Alice", 20, "Computer Science");
    const teacher = new Teacher("Mr. Smith", 40, "Mathematics");

    console.log(student.getDetails());
    console.log(teacher.getDetails());
  }, []);

  const student = new Student("Alice", 20, "Computer Science");
  const teacher = new Teacher("Mr. Smith", 40, "Mathematics");

  return (
    <div style={{ padding: '20px', fontFamily: 'Arial' }}>
      <h1>Person Class Hierarchy Demo</h1>
      <h2>Student</h2>
      <p>{student.getDetails()}</p>
      <h2>Teacher</h2>
      <p>{teacher.getDetails()}</p>
    </div>
  );
}

export default App;